var item_size = 4;

var item1 = {
    img         :"https://images.innisfree.co.kr/upload/product/30816_l_S_320.jpg?T202111300647",
    name        :"그린티 씨드 세럼 세트",
    price_old   :27000,
    price_cur   :18900,
    review      :603,
    brand       :"이니스프리",
    produce     :"국내산",
    statue      :"새 상품",
    color       :"네이비",
    size        :"S(90)"
};

var item2 = {
    img         :"https://images.innisfree.co.kr/upload/product/30883_p_S_320.jpg?T202111300647",
    name        :"그린티 프레시 샴푸바",
    price_old   :15000,
    price_cur   :10500,
    review      :200,
    brand       :"NATURE REPUBLIC",
    produce     :"국내산"
};

var item3 = {
    img         :"https://images.innisfree.co.kr/upload/mainMng/BM06_21_pc.jpg?T202111300647",
    name        :"듀이 틴트 립밤",
    price_old   :19900,
    price_cur   :15000,
    review      :263,
    brand       :"3CE",
    produce     :"중국산"
};

var item4 = {
    img         :"https://images.innisfree.co.kr/upload/mainMng/BM06_23_pc.jpg?T202111300647",
    name        :"[진정/수분/미백/결정돈]이 필요한 순간 마스크",
    price_old   :1500,
    price_cur   :1000,
    review      :563,
    brand       :"The Face Shop",
    produce     :"국내산"
};