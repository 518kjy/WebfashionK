itemPrint(item1);
itemPrint(item2);
itemPrint(item3);
itemPrint(item4);